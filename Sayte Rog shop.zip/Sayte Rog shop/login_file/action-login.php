<?php
if(
    isset($_POST['username']) && !empty($_POST['username'])&&
    isset($_POST['password']) && !empty($_POST['password'])
)
{
    $username = $_POST['username'];
    $password = $_POST['password'];
}else{
    exit("برخی از فیلدها مقدار دهی نشده");
}
$link=mysqli_connect("localhost","root","","rog_shop");
if  (mysqli_connect_errno()) exit("error404".mysqli_connect_errno());
$puery="SELECT `username`, `password` FROM `rog` WHERE username = '$username' AND password = '$password';";
$result = mysqli_query($link,$query);
$row=mysqli_fetch_array($result);
if($row)
echo("<P stylw='color:green;'><b>{$row[realname]}خوش امدید به سایت راگ شاپ </b></p>");
else
echo("<P style='color:red;'><b>نام کاربری یافت نشد </b></p>");
?>