<?php

if( isset($_POST['realname']) && !empty($_POST['realname']) &&
    isset($_POST['username']) && !empty($_POST['username'])&&
    isset($_POST['password']) && !empty($_POST['password'])&&
    isset($_POST['repassword']) && !empty($_POST['repassword'])&&
    isset($_POST['email']) && !empty($_POST['email'])){

        $realname = $_POST['realname'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $repassword = $_POST['repassword'];
        $email = $_POST['email'];
    }
    else
    exit("برخی از فیلدها مقدار دهی نشده");

    if($password != $repassword)
    exit("کلمه عبور و تکرار آن مشابه نیست");

    if(filter_var($email,FILTER_VALIDATE_EMAIL) === false)
    exit("پست الکترونیک وارد شده صحیح نیست");
    $link=mysqli_connect("localhost","root","","rog_shop");
    if  (mysqli_connect_errno()) exit("error404".mysqli_connect_errno());
    $query="INSERT INTO rog (realname,username,password,email,type)VALUES ('$realname','$username','$password','$email','0')";
    if(mysqli_query($link, $query)===true)
        echo("<P style ='colore:green'><b>عضویت شما با موفقیت تکمیل شد $realname </b></p>");
    else
    {
        echo("!!عضویت شما تکمیل نشد");
    }
    mysqli_close($link);
?>

<div dir="ltr" style="text-align: left;">

<?php
echo("realname: ".$realname. "<br/>");
echo("username: ".$username. "<br/>");
echo("password: ".$password. "<br/>");
echo("repassword: ".$repassword. "<br/>");
echo("email: ".$email. "<br/>");
?>

</div>
