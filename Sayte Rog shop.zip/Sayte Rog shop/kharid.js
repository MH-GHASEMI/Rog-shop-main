var plaus=1;
function ziad(){
 plaus++;
 document.getElementById("putmeghdar").value=plaus;
}
function kam(){
    plaus--;
    document.getElementById("putmeghdar").value=plaus;
   }