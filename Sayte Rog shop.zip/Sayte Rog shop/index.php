<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> 
        Rog shop.com
    </title>
    <link rel="stylesheet" href="Rog_main.css">
</head>
    <body id="main_body">
        <ul>
            <b>
            <li><a class="active" href="login.php" >حساب کاربری </a></li>
            <li><a href="#mtnertebat2">پشتیبانی</a></li>
            <li><a href="#"> سبد خرید</a></li>
            <li><a href="tel:+9944929868">تماس با ما</a></li>
            <div style="top: 15px;position: relative;display: inline-block;background-color: rgb(0, 0, 0);border-radius: 20px;">
                <button style="border-radius: 20px;width: 20px;height: 20px;padding: 4px;margin: 2px;background-image: url(pic/icons8-search-64.png);background-size: 100%100%;">
                </button>
                <input style="border-radius: 20px;">
                
                <span style="color: rgb(255, 0, 0);">جستجو</span>
            </div>
            <sub> فروشگاه اینترنتی راگ شاپ</sub>
            </b>
         </ul>  
        <p id="main_head">
            Rog shop
        </p>
        <div class="container">
            <!-- main -->
            <div class="row">
                <div class="col">
                    <div id="valed">
                        <div id="freefireid" >
                            <a href="freeefire id.html">
                                <button id="btnfreeid">
                                    <img src="pic/id.jpg" alt="">
                                    <br>
                                    <h1 id="mtnfreeif">خرید جم با ایدی   </h1>
                                </button>
                            </a>
                        </div>
                        <div id="kharid" >
                            <a href="https://t.me/freefire_Rog_shop">
                                <button id="kharidbtn">
                                    <img src="pic/kharidfree.jpg" alt="">
                                    <br>
                                    <h1 id="mtnkharid"> خرید اکانت فریفایر</h1>
                                </button>
                            </a>
                        </div>
                        <div id="freefireac" >
                            <a href="freefire account.html">
                                <button  id="btnfreeac">
                                    <img src="pic/acc.jpg" alt="">
                                    <h1 id="mtnfreeac"> خرید جم با اطلاعات </h1>
                                </button>
                            </a>
                    </div>                    
                </div>
            </div>
        </div>
        <!-- main -->
        </div>
        <br>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div id="valed2">
                        <div id="callof">
                            <a href="CP_Point_O'2.html">
                                <button id="callofbtn">
                                    <img src="pic/CP.jpg" alt="">
                                    <br>
                                        <h1 id="mtncallof"> خرید سی پی کالاف با اطلاعات </h1>
                                </button>
                            </a>
                        </div>
                        <br>
                        <br>
                        <div id="kharidac">
                            <a href="https://t.me/call_of_duty_Rog_shop">
                                <button id="kharidacbtn">
                                    <img src="pic/Call-of-Duty-Mobile.jpg" alt="">
                                    <br>
                                        <h1 id="mtnkharidac"> خرید اکانت فریفایر</h1>
                                </button>
                            </a>
                        </div>
                        <br>
                        <br>
                        <div id="pubg">
                                <a href="pubg.html">
                                    <button  id="pubgbtn">
                                        <img src="pic/uc.jpg" alt=""> 
                                            <h1 id="pubgmtn">خرید یوسی پابجی با ایدی</h1>
                                    </button>
                                </a>
                        </div>
                        </div>
                </div>
            </div>
        </div>
        
    </body>
    <br>
    <br>
    <br>
    <footer id="footer">
    <h6 style="color: rgb(0, 0, 0);text-align: right;">
        <b style="font-size: x-large;"> فروشگاه اینترنتی راگ شاپ</b>
    </h6>
         <h3 style="text-align: right;color: rgb(0, 0, 0);">
             <b>تیم راگ شاپ فعالیت خودش رو از سال 1402 بصورت تخصصی در زمینه فروش واحد های پولی درون برنامه ای شروع کرده و تا اکنون با بهترین قیمت، سرعت وکیفیت تمامی سفارشات مشتریان گرامی رو تکمیل کرده و همیشه بصورت 24 ساعته در کل هفته آماده خدمت رسانی به مشتریان عزیز میباشد </b>
             </h3>
                 <h2 style="color: rgb(0, 0, 0);text-align: right;"> راه های ارتباط با ما</h2>
                 <span style="text-align: left;">
                     <h4 style="color: rgb(0, 0, 0);display: block">Telegram :  <a style="color: #000000;" href="https://">@AmirmahdiPS </a></h4>
                     <h4 style="color: rgb(0, 0, 0);display: block;">instagram :<a style="color: rgb(0, 0, 0);" href="https://instagram.com/mmd_serius_ff?igshid=MzMyNGUyNmU2YQ=="> @mmd_serius_ff </a></h4>
                     <h4 style="color: rgb(0, 0, 0);display: block;">Rubika :<a style="color: rgb(0, 0, 0);" href="https://rubika.ir/MMD_SERIUS"> @mmd_serius_ff </a></h4>
                     <h4 style="color: rgb(0, 0, 0);display: block;"> phone number :  <a style="color: rgb(0, 0, 0);" href="tel:+9944929868">+9944929868</a></h4>
                 </span>
</footer>
</html>