<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>login.com</title>
</head>
<body id="background">
    <style>
        ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: rgb(red, rgb(0, 255, 0), rgb(0, 0, 255));
        }
        
        li {
        float: left;
        }
        li a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        }
        li a:hover {
        background-color: #000000;
        }
        </style>
                <ul style="font-size: 20px;font-family: Traditional Arabic;">
                    <b>
                    <li><a href="#mtnertebat2">پشتیبانی</a></li>
                    <li><a href="#"> سبد خرید</a></li>
                    <li><a href="tel:+98944929868">تماس با ما</a></li>
                    <li><a href="index.php">صفحه قبلی</a></li>
                    <li><a href="index.php">صفحه اصلی</a></li>
                    <div style="top: 15px;position: relative;display: inline-block;background-color: rgb(0, 0, 0);border-radius: 20px;">
                        <button style="border-radius: 20px;width: 20px;height: 20px;padding: 4px;margin: 2px;background-image: url(pic/icons8-search-64.png);background-size: 100%100%;">
                        </button>
                        <input style="border-radius: 20px;">
                        
                        <span style="color: rgb(255, 0, 0);">جستجو</span>
                    </div>
                    <sub style="color: aliceblue;float: right;padding: 12px;font-size: 24px;"> فروشگاه اینترنتی راگ شاپ</sub>
                    </b>
                 </ul>
                 <p id="rog">
                    Rog shop
                </p>

                 <p id="rog">
                    login
                 </p>
    <div id="valed">
        <form id="login"name="login" action="login_file/action-login.php" method="POST" style="background-image: url(pic/for\ .jpg);background-size: 100%100%;">
            <div id="user">
                <b id="mtnuser"> UserName:</b>
                <input type="text" style="text-align: left;" id="username" name="username"/>
            </div>
            <div id="user">
                <b id="mtnuser"> password:*</b>
                <input type="password" style="text-align: left;" id="password" name="password"/>
            </div>
            <input id="btn" type="submit" value="login"/>&nbsp;&nbsp;&nbsp;<a href="Cr-login.php"><button id="btn" type = "button">Create</button></a> 
        </form>
    </div>
    <br>
        <br>
        <br>
        <br>
</body>
<footer id="footer">
    <h6 style="color: rgb(0, 0, 0);text-align: right;">
        <b style="font-size: x-large;"> فروشگاه اینترنتی راگ شاپ</b>
    </h6>
         <h3 style="text-align: right;color: rgb(0, 0, 0);">
             <b>تیم راگ شاپ فعالیت خودش رو از سال 1402 بصورت تخصصی در زمینه فروش واحد های پولی درون برنامه ای شروع کرده و تا اکنون با بهترین قیمت، سرعت وکیفیت تمامی سفارشات مشتریان گرامی رو تکمیل کرده و همیشه بصورت 24 ساعته در کل هفته آماده خدمت رسانی به مشتریان عزیز میباشد </b>
             </h3>
                 <h2 style="color: rgb(0, 0, 0);text-align: right;"> راه های ارتباط با ما</h2>
                 <span style="text-align: left;">
                     <h4 style="color: rgb(0, 0, 0);display: block">Telegram :  <a style="color: #000000;" href="https://">@AmirmahdiPS </a></h4>
                     <h4 style="color: rgb(0, 0, 0);display: block;">instagram :<a style="color: rgb(0, 0, 0);" href="https://instagram.com/mmd_serius_ff?igshid=MzMyNGUyNmU2YQ=="> @mmd_serius_ff </a></h4>
                     <h4 style="color: rgb(0, 0, 0);display: block;">Rubika :<a style="color: rgb(0, 0, 0);" href="https://rubika.ir/MMD_SERIUS"> @mmd_serius_ff </a></h4>
                     <h4 style="color: rgb(0, 0, 0);display: block;"> phone number :  <a style="color: rgb(0, 0, 0);" href="tel:+9944929868">+9944929868</a></h4>
                 </span>
</footer>
</html>