var us,pas,phon,cd;
us = (document.getElementById("inputuser").value);
phon = Number(document.getElementById("inphone").value);
pas = (document.getElementById("inputpass").value);
cd = (document.getElementById("in-cod").value);
function btnlogin(){

    if (cd=='0741538701')
    <b>true</b>
    else
    <b>try again</b>
}
    